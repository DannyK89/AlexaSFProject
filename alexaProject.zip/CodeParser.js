/*
  This class is used to parse the the spoken string that is sent to
  it by Amazon Echo. It will take the spoken words and turn them
  into code for the salesforce system.
*/

module.exports.parseString = function(stringSpoken) {
  var codeSnipit = stringSpoken;

  return codeSnipit;
}
